public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, Git!");
        System.out.println("Experiment 1 - Git Basics");
        System.out.println("Feature Update Branch");
        displayWelcomeMessage();
    }
    
    public static void displayWelcomeMessage() {
        System.out.println("Welcome to Git Branching!");
    }
}
